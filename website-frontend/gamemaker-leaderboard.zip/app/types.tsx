export interface Match {
  matchId: number
  players: string[]
  roundWinners: string[]
  matchWinner: string
}
